create definer = poem@`%` view getLikeUser as
select `lu`.`uid`              AS `uid`,
       `lu`.`likeuid`          AS `likeuid`,
       `u`.`uname`             AS `uname`,
       `u`.`nickname`          AS `nickname`,
       `u`.`email`             AS `email`,
       `u`.`tel`               AS `tel`,
       `u`.`slogan`            AS `slogan`,
       `u`.`sex`               AS `sex`,
       `u`.`birthday`          AS `birthday`,
       `u`.`regtime`           AS `regtime`,
       `u`.`likepoemnumber`    AS `likepoemnumber`,
       `u`.`likecommentnumber` AS `likecommentnumber`,
       `u`.`commentnumber`     AS `commentnumber`,
       `u`.`likeusernumber`    AS `likeusernumber`,
       `u`.`likedusernumber`   AS `likedusernumber`,
       `u`.`assets`            AS `assets`,
       `u`.`exp`               AS `exp`,
       `u`.`level`             AS `level`,
       `u`.`regip`             AS `regip`
from (`poem`.`likeuser` `lu`
         left join `poem`.`user` `u` on ((`lu`.`likeuid` = `u`.`uid`)));

-- comment on column getLikeUser.uid not supported: 用户编号

-- comment on column getLikeUser.likeuid not supported: 喜欢的用户编号

-- comment on column getLikeUser.uname not supported: 用户名

-- comment on column getLikeUser.nickname not supported: 昵称

-- comment on column getLikeUser.email not supported: 邮箱

-- comment on column getLikeUser.tel not supported: 手机号码

-- comment on column getLikeUser.slogan not supported: 个性签名

-- comment on column getLikeUser.sex not supported: 性别

-- comment on column getLikeUser.birthday not supported: 出生日期

-- comment on column getLikeUser.regtime not supported: 注册日期

-- comment on column getLikeUser.likepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getLikeUser.likecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getLikeUser.commentnumber not supported: 评论数量，默认0

-- comment on column getLikeUser.likeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getLikeUser.likedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getLikeUser.assets not supported: 资产

-- comment on column getLikeUser.exp not supported: 经验

-- comment on column getLikeUser.level not supported: 用户级别0未激活1普通用户2管理员

-- comment on column getLikeUser.regip not supported: 注册ip

