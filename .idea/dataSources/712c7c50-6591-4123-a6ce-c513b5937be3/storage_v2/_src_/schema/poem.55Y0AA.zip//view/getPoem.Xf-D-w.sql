create view getPoem as
select `poem`.`poem`.`pid`            AS `pid`,
       `poem`.`poem`.`title`          AS `title`,
       `poem`.`poem`.`did`            AS `did`,
       `poem`.`poem`.`aid`            AS `aid`,
       `poem`.`poem`.`content`        AS `content`,
       `poem`.`poem`.`likepoemnumber` AS `likepoemnumber`,
       `poem`.`poem`.`commentnumber`  AS `commentnumber`,
       `poem`.`poem`.`active`         AS `active`,
       `poem`.`dynasty`.`dname`       AS `dname`,
       `poem`.`dynasty`.`active`      AS `dactive`,
       `poem`.`author`.`aname`        AS `aname`,
       `poem`.`author`.`active`       AS `aactive`
from ((`poem`.`poem` join `poem`.`dynasty`)
         join `poem`.`author`)
where ((`poem`.`poem`.`aid` = `poem`.`author`.`aid`) and (`poem`.`poem`.`did` = `poem`.`dynasty`.`did`));

-- comment on column getPoem.pid not supported: 诗词编号

-- comment on column getPoem.title not supported: 诗词题目

-- comment on column getPoem.did not supported: 朝代编号

-- comment on column getPoem.aid not supported: 作者编号

-- comment on column getPoem.content not supported: 诗词内容

-- comment on column getPoem.likepoemnumber not supported: 喜欢数量

-- comment on column getPoem.commentnumber not supported: 评论数量

-- comment on column getPoem.active not supported: 是否可用1,不可用0，默认1

-- comment on column getPoem.dname not supported: 朝代名称

-- comment on column getPoem.dactive not supported: 是否可用1,不可用0，默认1

-- comment on column getPoem.aname not supported: 作者名称

-- comment on column getPoem.aactive not supported: 是否可用1,不可用0
，默认1

