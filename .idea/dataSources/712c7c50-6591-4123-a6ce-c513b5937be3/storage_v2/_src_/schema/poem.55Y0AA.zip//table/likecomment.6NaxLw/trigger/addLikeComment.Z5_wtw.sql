create definer = root@localhost trigger addLikeComment
    after insert
    on likecomment
    for each row
BEGIN
UPDATE poem.`user` SET `user`.`likecommentnumber` = `user`.`likecommentnumber`+1 WHERE `user`.uid=new.uid;
UPDATE poem.`comment` SET `comment`.`likenumber` = `comment`.`likenumber`+1 WHERE `comment`.cid=new.cid;
END;

