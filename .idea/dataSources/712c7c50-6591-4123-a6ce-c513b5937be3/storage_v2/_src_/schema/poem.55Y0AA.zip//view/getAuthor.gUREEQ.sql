create view getAuthor as
select `poem`.`author`.`aname`                                                                                    AS `aname`,
       `poem`.`author`.`aid`                                                                                      AS `aid`,
       `poem`.`author`.`did`                                                                                      AS `did`,
       `poem`.`author`.`active`                                                                                   AS `active`,
       (select count(`poem`.`poem`.`pid`)
        from `poem`.`poem`
        where (`poem`.`poem`.`aid` = `poem`.`author`.`aid`))                                                      AS `poemcount`,
       `poem`.`dynasty`.`dname`                                                                                   AS `dname`,
       `poem`.`dynasty`.`active`                                                                                  AS `dactive`
from (`poem`.`author`
         left join `poem`.`dynasty` on ((`poem`.`author`.`did` = `poem`.`dynasty`.`did`)))
order by `poemcount` desc;

-- comment on column getAuthor.aname not supported: 作者名称

-- comment on column getAuthor.aid not supported: 作者编号

-- comment on column getAuthor.did not supported: 朝代编号

-- comment on column getAuthor.active not supported: 是否可用1,不可用0
，默认1

-- comment on column getAuthor.dname not supported: 朝代名称

-- comment on column getAuthor.dactive not supported: 是否可用1,不可用0，默认1

