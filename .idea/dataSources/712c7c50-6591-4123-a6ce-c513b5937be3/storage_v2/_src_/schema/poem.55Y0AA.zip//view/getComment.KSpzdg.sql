create definer = poem@`%` view getComment as
select `poem`.`comment`.`cid`            AS `cid`,
       `poem`.`comment`.`uid`            AS `uid`,
       `poem`.`comment`.`type`           AS `type`,
       `poem`.`comment`.`id`             AS `id`,
       `poem`.`comment`.`title`          AS `title`,
       `poem`.`comment`.`content`        AS `content`,
       `poem`.`comment`.`sendtime`       AS `sendtime`,
       `poem`.`comment`.`public`         AS `public`,
       `poem`.`comment`.`active`         AS `active`,
       `poem`.`user`.`uname`             AS `uname`,
       `poem`.`user`.`nickname`          AS `nickname`,
       `poem`.`user`.`email`             AS `email`,
       `poem`.`user`.`tel`               AS `tel`,
       `poem`.`user`.`slogan`            AS `slogan`,
       `poem`.`user`.`sex`               AS `sex`,
       `poem`.`user`.`birthday`          AS `birthday`,
       `poem`.`user`.`regtime`           AS `regtime`,
       `poem`.`user`.`likepoemnumber`    AS `ulikepoemnumber`,
       `poem`.`user`.`likecommentnumber` AS `ulikecommentnumber`,
       `poem`.`user`.`commentnumber`     AS `ucommentnumber`,
       `poem`.`user`.`likeusernumber`    AS `ulikeusernumber`,
       `poem`.`user`.`likedusernumber`   AS `ulikedusernumber`,
       `poem`.`user`.`assets`            AS `assets`,
       `poem`.`user`.`exp`               AS `exp`,
       `poem`.`user`.`level`             AS `level`,
       `poem`.`comment`.`likenumber`     AS `likenumber`,
       `poem`.`comment`.`commentnumber`  AS `commentnumber`
from (`poem`.`comment`
         left join `poem`.`user` on ((`poem`.`comment`.`uid` = `poem`.`user`.`uid`)));

-- comment on column getComment.cid not supported: 评论编号

-- comment on column getComment.uid not supported: 用户编号

-- comment on column getComment.type not supported: p:诗词,c:评论,f:反馈,n:新闻,u:用户

-- comment on column getComment.id not supported: type决定的编号

-- comment on column getComment.title not supported: 标题

-- comment on column getComment.content not supported: 内容

-- comment on column getComment.sendtime not supported: 发送时间

-- comment on column getComment.public not supported: 是否公开1私密0默认1

-- comment on column getComment.active not supported: 是否有效

-- comment on column getComment.uname not supported: 用户名

-- comment on column getComment.nickname not supported: 昵称

-- comment on column getComment.email not supported: 邮箱

-- comment on column getComment.tel not supported: 手机号码

-- comment on column getComment.slogan not supported: 个性签名

-- comment on column getComment.sex not supported: 性别

-- comment on column getComment.birthday not supported: 出生日期

-- comment on column getComment.regtime not supported: 注册日期

-- comment on column getComment.ulikepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getComment.ulikecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getComment.ucommentnumber not supported: 评论数量，默认0

-- comment on column getComment.ulikeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getComment.ulikedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getComment.assets not supported: 资产

-- comment on column getComment.exp not supported: 经验

-- comment on column getComment.level not supported: 用户级别0未激活1普通用户2管理员

-- comment on column getComment.likenumber not supported: 收藏的人数

-- comment on column getComment.commentnumber not supported: 评论数

