create view getComment as
select `poem`.`comment`.`cid`            AS `cid`,
       `poem`.`comment`.`uid`            AS `uid`,
       `poem`.`comment`.`pid`            AS `pid`,
       `poem`.`user`.`uname`             AS `uname`,
       `poem`.`poem`.`did`               AS `did`,
       `poem`.`poem`.`aid`               AS `aid`,
       `poem`.`dynasty`.`dname`          AS `dname`,
       `poem`.`dynasty`.`active`         AS `dactive`,
       `poem`.`poem`.`active`            AS `pactive`,
       `poem`.`poem`.`likepoemnumber`    AS `plikepoemnumber`,
       `poem`.`poem`.`commentnumber`     AS `pcommentnumber`,
       `poem`.`author`.`aname`           AS `aname`,
       `poem`.`author`.`active`          AS `aactive`,
       `poem`.`comment`.`public`         AS `public`,
       `poem`.`comment`.`title`          AS `title`,
       `poem`.`comment`.`content`        AS `content`,
       `poem`.`comment`.`sendtime`       AS `sendtime`,
       `poem`.`comment`.`altertime`      AS `altertime`,
       `poem`.`poem`.`title`             AS `ptitle`,
       `poem`.`poem`.`content`           AS `pcontent`,
       `poem`.`user`.`nickname`          AS `nickname`,
       `poem`.`user`.`email`             AS `email`,
       `poem`.`user`.`tel`               AS `tel`,
       `poem`.`user`.`slogan`            AS `slogan`,
       `poem`.`user`.`sex`               AS `sex`,
       `poem`.`user`.`birthday`          AS `birthday`,
       `poem`.`user`.`regtime`           AS `regtime`,
       `poem`.`user`.`likepoemnumber`    AS `likepoemnumber`,
       `poem`.`user`.`likecommentnumber` AS `likecommentnumber`,
       `poem`.`user`.`commentnumber`     AS `commentnumber`,
       `poem`.`user`.`likeusernumber`    AS `likeusernumber`,
       `poem`.`user`.`likedusernumber`   AS `likedusernumber`,
       `poem`.`user`.`avatar`            AS `avatar`,
       `poem`.`user`.`assets`            AS `assets`,
       `poem`.`user`.`exp`               AS `exp`,
       `poem`.`user`.`level`             AS `level`
from ((((`poem`.`comment` join `poem`.`user` on ((`poem`.`comment`.`uid` = `poem`.`user`.`uid`))) join `poem`.`poem` on ((`poem`.`comment`.`pid` = `poem`.`poem`.`pid`))) join `poem`.`dynasty` on ((`poem`.`poem`.`did` = `poem`.`dynasty`.`did`)))
         join `poem`.`author` on ((`poem`.`poem`.`aid` = `poem`.`author`.`aid`)));

-- comment on column getComment.cid not supported: 评论编号

-- comment on column getComment.uid not supported: 用户编号

-- comment on column getComment.pid not supported: 诗词编号

-- comment on column getComment.uname not supported: 用户名

-- comment on column getComment.did not supported: 朝代编号

-- comment on column getComment.aid not supported: 作者编号

-- comment on column getComment.dname not supported: 朝代名称

-- comment on column getComment.dactive not supported: 是否可用1,不可用0，默认1

-- comment on column getComment.pactive not supported: 是否可用1,不可用0，默认1

-- comment on column getComment.plikepoemnumber not supported: 喜欢数量

-- comment on column getComment.pcommentnumber not supported: 评论数量

-- comment on column getComment.aname not supported: 作者名称

-- comment on column getComment.aactive not supported: 是否可用1,不可用0
，默认1

-- comment on column getComment.public not supported: 是否公开1私密0默认1

-- comment on column getComment.title not supported: 标题

-- comment on column getComment.content not supported: 内容

-- comment on column getComment.sendtime not supported: 发送时间

-- comment on column getComment.altertime not supported: 最后修改时间

-- comment on column getComment.ptitle not supported: 诗词题目

-- comment on column getComment.pcontent not supported: 诗词内容

-- comment on column getComment.nickname not supported: 昵称

-- comment on column getComment.email not supported: 邮箱

-- comment on column getComment.tel not supported: 手机号码

-- comment on column getComment.slogan not supported: 个性签名

-- comment on column getComment.sex not supported: 性别

-- comment on column getComment.birthday not supported: 出生日期

-- comment on column getComment.regtime not supported: 注册日期

-- comment on column getComment.likepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getComment.likecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getComment.commentnumber not supported: 评论数量，默认0

-- comment on column getComment.likeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getComment.likedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getComment.avatar not supported: 头像，默认.png

-- comment on column getComment.assets not supported: 资产

-- comment on column getComment.exp not supported: 经验

-- comment on column getComment.level not supported: 用户级别0未激活1普通用户2管理员

