create definer = root@localhost trigger addComment
    after insert
    on comment
    for each row
BEGIN
	UPDATE poem.`user` SET `user`.`commentnumber` = `user`.`commentnumber`+1 WHERE `user`.uid=new.uid;
IF new.type='p' THEN
	UPDATE poem.`poem` SET `poem`.`commentnumber` = `poem`.`commentnumber`+1 WHERE `poem`.pid=new.id;
ELSEIF new.type='n' THEN
	UPDATE poem.`news` SET `news`.`commentnumber` = `news`.`commentnumber`+1 WHERE `news`.nid=new.id;
ELSEIF new.type='f' THEN
	UPDATE poem.`feedback` SET `feedback`.`commentnumber` = `feedback`.`commentnumber`+1 WHERE `feedback`.fid=new.id;
END IF;
END;

