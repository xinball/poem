create definer = root@localhost trigger addComment
    after insert
    on comment
    for each row
BEGIN
UPDATE poem.`user` SET `user`.`commentnumber` = `user`.`commentnumber`+1 WHERE `user`.uid=new.uid;
UPDATE poem.`poem` SET `poem`.`commentnumber` = `poem`.`commentnumber`+1 WHERE `poem`.pid=new.pid;
END;

