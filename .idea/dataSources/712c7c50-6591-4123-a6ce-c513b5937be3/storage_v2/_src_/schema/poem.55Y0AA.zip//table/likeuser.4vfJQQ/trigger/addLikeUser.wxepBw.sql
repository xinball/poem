create definer = root@localhost trigger addLikeUser
    after insert
    on likeuser
    for each row
BEGIN
UPDATE poem.`user` SET `user`.likeusernumber = `user`.likeusernumber+1 WHERE `user`.uid=new.uid;
UPDATE poem.`user` SET `user`.likedusernumber = `user`.likedusernumber+1 WHERE `user`.uid=new.likeuid;
END;

