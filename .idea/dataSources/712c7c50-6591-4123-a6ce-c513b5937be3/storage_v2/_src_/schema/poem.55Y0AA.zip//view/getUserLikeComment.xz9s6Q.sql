create definer = poem@`%` view getUserLikeComment as
select `poem`.`likecomment`.`cid`        AS `cid`,
       `poem`.`likecomment`.`uid`        AS `uid`,
       `poem`.`user`.`uname`             AS `uname`,
       `poem`.`user`.`nickname`          AS `nickname`,
       `poem`.`user`.`email`             AS `email`,
       `poem`.`user`.`tel`               AS `tel`,
       `poem`.`user`.`slogan`            AS `slogan`,
       `poem`.`user`.`sex`               AS `sex`,
       `poem`.`user`.`birthday`          AS `birthday`,
       `poem`.`user`.`regtime`           AS `regtime`,
       `poem`.`user`.`likepoemnumber`    AS `likepoemnumber`,
       `poem`.`user`.`likecommentnumber` AS `likecommentnumber`,
       `poem`.`user`.`commentnumber`     AS `commentnumber`,
       `poem`.`user`.`likeusernumber`    AS `likeusernumber`,
       `poem`.`user`.`likedusernumber`   AS `likedusernumber`,
       `poem`.`user`.`assets`            AS `assets`,
       `poem`.`user`.`exp`               AS `exp`,
       `poem`.`user`.`level`             AS `level`
from (`poem`.`likecomment`
         left join `poem`.`user` on ((`poem`.`likecomment`.`uid` = `poem`.`user`.`uid`)));

-- comment on column getUserLikeComment.cid not supported: 喜欢的诗词编号

-- comment on column getUserLikeComment.uid not supported: 用户编号

-- comment on column getUserLikeComment.uname not supported: 用户名

-- comment on column getUserLikeComment.nickname not supported: 昵称

-- comment on column getUserLikeComment.email not supported: 邮箱

-- comment on column getUserLikeComment.tel not supported: 手机号码

-- comment on column getUserLikeComment.slogan not supported: 个性签名

-- comment on column getUserLikeComment.sex not supported: 性别

-- comment on column getUserLikeComment.birthday not supported: 出生日期

-- comment on column getUserLikeComment.regtime not supported: 注册日期

-- comment on column getUserLikeComment.likepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getUserLikeComment.likecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getUserLikeComment.commentnumber not supported: 评论数量，默认0

-- comment on column getUserLikeComment.likeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getUserLikeComment.likedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getUserLikeComment.assets not supported: 资产

-- comment on column getUserLikeComment.exp not supported: 经验

-- comment on column getUserLikeComment.level not supported: 用户级别0未激活1普通用户2管理员

