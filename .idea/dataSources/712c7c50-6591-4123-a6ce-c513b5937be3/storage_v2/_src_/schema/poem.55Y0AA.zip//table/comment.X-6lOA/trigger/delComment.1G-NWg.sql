create definer = root@localhost trigger delComment
    after delete
    on comment
    for each row
BEGIN
UPDATE poem.`user` SET `user`.`commentnumber` = `user`.`commentnumber`-1 WHERE `user`.uid=old.uid;
UPDATE poem.`poem` SET `poem`.`commentnumber` = `poem`.`commentnumber`-1 WHERE `poem`.pid=old.pid;
END;

