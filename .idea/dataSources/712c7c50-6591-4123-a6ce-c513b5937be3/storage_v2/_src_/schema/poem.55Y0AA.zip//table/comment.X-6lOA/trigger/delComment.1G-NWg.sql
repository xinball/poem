create definer = root@localhost trigger delComment
    after delete
    on comment
    for each row
BEGIN
UPDATE poem.`user` SET `user`.`commentnumber` = `user`.`commentnumber`-1 WHERE `user`.uid=old.uid;
IF old.type='p' THEN
	UPDATE poem.`poem` SET `poem`.`commentnumber` = `poem`.`commentnumber`-1 WHERE `poem`.pid=old.id;
ELSEIF old.type='n' THEN
	UPDATE poem.`news` SET `news`.`commentnumber` = `news`.`commentnumber`-1 WHERE `news`.nid=old.id;
ELSEIF old.type='f' THEN
	UPDATE poem.`feedback` SET `feedback`.`commentnumber` = `feedback`.`commentnumber`-1 WHERE `feedback`.fid=old.id;
END IF;
END;

