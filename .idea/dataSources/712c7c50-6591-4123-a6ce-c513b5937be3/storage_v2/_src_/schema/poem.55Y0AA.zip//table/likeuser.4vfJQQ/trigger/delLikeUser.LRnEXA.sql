create definer = root@localhost trigger delLikeUser
    after delete
    on likeuser
    for each row
BEGIN UPDATE poem.`user` SET `user`.likeusernumber = `user`.likeusernumber-1 WHERE `user`.uid=OLD.uid; UPDATE poem.`user` SET `user`.likedusernumber = `user`.likedusernumber-1 WHERE `user`.uid=OLD.likeuid; END;

