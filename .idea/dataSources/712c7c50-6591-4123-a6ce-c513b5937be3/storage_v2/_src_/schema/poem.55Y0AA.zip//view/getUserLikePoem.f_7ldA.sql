create view getUserLikePoem as
select `poem`.`likepoem`.`uid`           AS `uid`,
       `poem`.`likepoem`.`pid`           AS `pid`,
       `poem`.`user`.`uname`             AS `uname`,
       `poem`.`user`.`password`          AS `password`,
       `poem`.`user`.`nickname`          AS `nickname`,
       `poem`.`user`.`email`             AS `email`,
       `poem`.`user`.`tel`               AS `tel`,
       `poem`.`user`.`slogan`            AS `slogan`,
       `poem`.`user`.`sex`               AS `sex`,
       `poem`.`user`.`birthday`          AS `birthday`,
       `poem`.`user`.`regtime`           AS `regtime`,
       `poem`.`user`.`regip`             AS `regip`,
       `poem`.`user`.`likepoemnumber`    AS `likepoemnumber`,
       `poem`.`user`.`likecommentnumber` AS `likecommentnumber`,
       `poem`.`user`.`commentnumber`     AS `commentnumber`,
       `poem`.`user`.`likeusernumber`    AS `likeusernumber`,
       `poem`.`user`.`likedusernumber`   AS `likedusernumber`,
       `poem`.`user`.`sid`               AS `sid`,
       `poem`.`user`.`avatar`            AS `avatar`,
       `poem`.`user`.`assets`            AS `assets`,
       `poem`.`user`.`exp`               AS `exp`,
       `poem`.`user`.`level`             AS `level`
from (`poem`.`likepoem`
         join `poem`.`user` on ((`poem`.`likepoem`.`uid` = `poem`.`user`.`uid`)));

-- comment on column getUserLikePoem.uid not supported: 用户编号

-- comment on column getUserLikePoem.pid not supported: 喜欢的诗词编号

-- comment on column getUserLikePoem.uname not supported: 用户名

-- comment on column getUserLikePoem.password not supported: 密码

-- comment on column getUserLikePoem.nickname not supported: 昵称

-- comment on column getUserLikePoem.email not supported: 邮箱

-- comment on column getUserLikePoem.tel not supported: 手机号码

-- comment on column getUserLikePoem.slogan not supported: 个性签名

-- comment on column getUserLikePoem.sex not supported: 性别

-- comment on column getUserLikePoem.birthday not supported: 出生日期

-- comment on column getUserLikePoem.regtime not supported: 注册日期

-- comment on column getUserLikePoem.regip not supported: 注册ip

-- comment on column getUserLikePoem.likepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getUserLikePoem.likecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getUserLikePoem.commentnumber not supported: 评论数量，默认0

-- comment on column getUserLikePoem.likeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getUserLikePoem.likedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getUserLikePoem.sid not supported: 皮肤编号，默认0

-- comment on column getUserLikePoem.avatar not supported: 头像，默认.png

-- comment on column getUserLikePoem.assets not supported: 资产

-- comment on column getUserLikePoem.exp not supported: 经验

-- comment on column getUserLikePoem.level not supported: 用户级别0未激活1普通用户2管理员

