create view getCommentLikedUser as
select `poem`.`likecomment`.`uid`       AS `uuid`,
       `poem`.`likecomment`.`cid`       AS `cid`,
       `getComment`.`uid`               AS `uid`,
       `getComment`.`pid`               AS `pid`,
       `getComment`.`uname`             AS `uname`,
       `getComment`.`did`               AS `did`,
       `getComment`.`aid`               AS `aid`,
       `getComment`.`dname`             AS `dname`,
       `getComment`.`dactive`           AS `dactive`,
       `getComment`.`pactive`           AS `pactive`,
       `getComment`.`plikepoemnumber`   AS `plikepoemnumber`,
       `getComment`.`pcommentnumber`    AS `pcommentnumber`,
       `getComment`.`aname`             AS `aname`,
       `getComment`.`aactive`           AS `aactive`,
       `getComment`.`public`            AS `public`,
       `getComment`.`title`             AS `title`,
       `getComment`.`content`           AS `content`,
       `getComment`.`sendtime`          AS `sendtime`,
       `getComment`.`altertime`         AS `altertime`,
       `getComment`.`ptitle`            AS `ptitle`,
       `getComment`.`pcontent`          AS `pcontent`,
       `getComment`.`nickname`          AS `nickname`,
       `getComment`.`email`             AS `email`,
       `getComment`.`tel`               AS `tel`,
       `getComment`.`slogan`            AS `slogan`,
       `getComment`.`sex`               AS `sex`,
       `getComment`.`birthday`          AS `birthday`,
       `getComment`.`regtime`           AS `regtime`,
       `getComment`.`likepoemnumber`    AS `likepoemnumber`,
       `getComment`.`likecommentnumber` AS `likecommentnumber`,
       `getComment`.`commentnumber`     AS `commentnumber`,
       `getComment`.`likeusernumber`    AS `likeusernumber`,
       `getComment`.`likedusernumber`   AS `likedusernumber`,
       `getComment`.`avatar`            AS `avatar`,
       `getComment`.`assets`            AS `assets`,
       `getComment`.`exp`               AS `exp`,
       `getComment`.`level`             AS `level`
from (`poem`.`likecomment`
         join `poem`.`getComment` on ((`getComment`.`cid` = `poem`.`likecomment`.`cid`)));

-- comment on column getCommentLikedUser.uuid not supported: 用户编号

-- comment on column getCommentLikedUser.cid not supported: 喜欢的诗词编号

-- comment on column getCommentLikedUser.uid not supported: 用户编号

-- comment on column getCommentLikedUser.pid not supported: 诗词编号

-- comment on column getCommentLikedUser.uname not supported: 用户名

-- comment on column getCommentLikedUser.did not supported: 朝代编号

-- comment on column getCommentLikedUser.aid not supported: 作者编号

-- comment on column getCommentLikedUser.dname not supported: 朝代名称

-- comment on column getCommentLikedUser.dactive not supported: 是否可用1,不可用0，默认1

-- comment on column getCommentLikedUser.pactive not supported: 是否可用1,不可用0，默认1

-- comment on column getCommentLikedUser.plikepoemnumber not supported: 喜欢数量

-- comment on column getCommentLikedUser.pcommentnumber not supported: 评论数量

-- comment on column getCommentLikedUser.aname not supported: 作者名称

-- comment on column getCommentLikedUser.aactive not supported: 是否可用1,不可用0
，默认1

-- comment on column getCommentLikedUser.public not supported: 是否公开1私密0默认1

-- comment on column getCommentLikedUser.title not supported: 标题

-- comment on column getCommentLikedUser.content not supported: 内容

-- comment on column getCommentLikedUser.sendtime not supported: 发送时间

-- comment on column getCommentLikedUser.altertime not supported: 最后修改时间

-- comment on column getCommentLikedUser.ptitle not supported: 诗词题目

-- comment on column getCommentLikedUser.pcontent not supported: 诗词内容

-- comment on column getCommentLikedUser.nickname not supported: 昵称

-- comment on column getCommentLikedUser.email not supported: 邮箱

-- comment on column getCommentLikedUser.tel not supported: 手机号码

-- comment on column getCommentLikedUser.slogan not supported: 个性签名

-- comment on column getCommentLikedUser.sex not supported: 性别

-- comment on column getCommentLikedUser.birthday not supported: 出生日期

-- comment on column getCommentLikedUser.regtime not supported: 注册日期

-- comment on column getCommentLikedUser.likepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getCommentLikedUser.likecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getCommentLikedUser.commentnumber not supported: 评论数量，默认0

-- comment on column getCommentLikedUser.likeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getCommentLikedUser.likedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getCommentLikedUser.avatar not supported: 头像，默认.png

-- comment on column getCommentLikedUser.assets not supported: 资产

-- comment on column getCommentLikedUser.exp not supported: 经验

-- comment on column getCommentLikedUser.level not supported: 用户级别0未激活1普通用户2管理员

