create definer = poem@`%` view getCommentLikedUser as
select `poem`.`likecomment`.`uid`        AS `uid`,
       `poem`.`likecomment`.`cid`        AS `cid`,
       `getComment`.`uid`                AS `cuid`,
       `getComment`.`type`               AS `type`,
       `getComment`.`id`                 AS `id`,
       `getComment`.`title`              AS `title`,
       `getComment`.`content`            AS `content`,
       `getComment`.`sendtime`           AS `sendtime`,
       `getComment`.`public`             AS `public`,
       `getComment`.`active`             AS `active`,
       `getComment`.`uname`              AS `uname`,
       `getComment`.`nickname`           AS `nickname`,
       `getComment`.`email`              AS `email`,
       `getComment`.`tel`                AS `tel`,
       `getComment`.`slogan`             AS `slogan`,
       `getComment`.`sex`                AS `sex`,
       `getComment`.`birthday`           AS `birthday`,
       `getComment`.`regtime`            AS `regtime`,
       `getComment`.`ulikepoemnumber`    AS `ulikepoemnumber`,
       `getComment`.`ulikecommentnumber` AS `ulikecommentnumber`,
       `getComment`.`ucommentnumber`     AS `ucommentnumber`,
       `getComment`.`ulikeusernumber`    AS `ulikeusernumber`,
       `getComment`.`ulikedusernumber`   AS `ulikedusernumber`,
       `getComment`.`assets`             AS `assets`,
       `getComment`.`exp`                AS `exp`,
       `getComment`.`level`              AS `level`,
       `getComment`.`likenumber`         AS `likenumber`,
       `getComment`.`commentnumber`      AS `commentnumber`
from (`poem`.`likecomment`
         left join `poem`.`getComment` on ((`poem`.`likecomment`.`cid` = `getComment`.`cid`)));

-- comment on column getCommentLikedUser.uid not supported: 用户编号

-- comment on column getCommentLikedUser.cid not supported: 喜欢的诗词编号

-- comment on column getCommentLikedUser.cuid not supported: 用户编号

-- comment on column getCommentLikedUser.type not supported: p:诗词,c:评论,f:反馈,n:新闻,u:用户

-- comment on column getCommentLikedUser.id not supported: type决定的编号

-- comment on column getCommentLikedUser.title not supported: 标题

-- comment on column getCommentLikedUser.content not supported: 内容

-- comment on column getCommentLikedUser.sendtime not supported: 发送时间

-- comment on column getCommentLikedUser.public not supported: 是否公开1私密0默认1

-- comment on column getCommentLikedUser.active not supported: 是否有效

-- comment on column getCommentLikedUser.uname not supported: 用户名

-- comment on column getCommentLikedUser.nickname not supported: 昵称

-- comment on column getCommentLikedUser.email not supported: 邮箱

-- comment on column getCommentLikedUser.tel not supported: 手机号码

-- comment on column getCommentLikedUser.slogan not supported: 个性签名

-- comment on column getCommentLikedUser.sex not supported: 性别

-- comment on column getCommentLikedUser.birthday not supported: 出生日期

-- comment on column getCommentLikedUser.regtime not supported: 注册日期

-- comment on column getCommentLikedUser.ulikepoemnumber not supported: 喜欢的诗词数量，默认0

-- comment on column getCommentLikedUser.ulikecommentnumber not supported: 喜欢的评论数量，默认0

-- comment on column getCommentLikedUser.ucommentnumber not supported: 评论数量，默认0

-- comment on column getCommentLikedUser.ulikeusernumber not supported: 喜欢的用户数量，默认0

-- comment on column getCommentLikedUser.ulikedusernumber not supported: 喜欢你的用户数量，默认0

-- comment on column getCommentLikedUser.assets not supported: 资产

-- comment on column getCommentLikedUser.exp not supported: 经验

-- comment on column getCommentLikedUser.level not supported: 用户级别0未激活1普通用户2管理员

-- comment on column getCommentLikedUser.likenumber not supported: 收藏的人数

-- comment on column getCommentLikedUser.commentnumber not supported: 评论数

