create definer = root@localhost trigger addLikePoem
    after insert
    on likepoem
    for each row
BEGIN
UPDATE poem.`user` SET `user`.likepoemnumber = `user`.likepoemnumber+1 WHERE `user`.uid=new.uid;
UPDATE poem.`poem` SET `poem`.likepoemnumber = `poem`.likepoemnumber+1 WHERE `poem`.pid=new.pid;
END;

