create definer = poem@`%` view getPoemLikedUser as
select `poem`.`likepoem`.`uid`    AS `uid`,
       `poem`.`likepoem`.`pid`    AS `pid`,
       `getPoem`.`title`          AS `title`,
       `getPoem`.`did`            AS `did`,
       `getPoem`.`aid`            AS `aid`,
       `getPoem`.`content`        AS `content`,
       `getPoem`.`likepoemnumber` AS `likepoemnumber`,
       `getPoem`.`commentnumber`  AS `commentnumber`,
       `getPoem`.`active`         AS `active`,
       `getPoem`.`aname`          AS `aname`,
       `getPoem`.`aactive`        AS `aactive`,
       `getPoem`.`dname`          AS `dname`,
       `getPoem`.`dactive`        AS `dactive`
from (`poem`.`likepoem`
         left join `poem`.`getPoem` on ((`poem`.`likepoem`.`pid` = `getPoem`.`pid`)));

-- comment on column getPoemLikedUser.uid not supported: 用户编号

-- comment on column getPoemLikedUser.pid not supported: 喜欢的诗词编号

-- comment on column getPoemLikedUser.title not supported: 诗词题目

-- comment on column getPoemLikedUser.did not supported: 朝代编号

-- comment on column getPoemLikedUser.aid not supported: 作者编号

-- comment on column getPoemLikedUser.content not supported: 诗词内容

-- comment on column getPoemLikedUser.likepoemnumber not supported: 喜欢数量

-- comment on column getPoemLikedUser.commentnumber not supported: 评论数量

-- comment on column getPoemLikedUser.active not supported: 是否可用1,不可用0，默认1

-- comment on column getPoemLikedUser.aname not supported: 作者名称

-- comment on column getPoemLikedUser.aactive not supported: 是否可用1,不可用0
，默认1

-- comment on column getPoemLikedUser.dname not supported: 朝代名称

-- comment on column getPoemLikedUser.dactive not supported: 是否可用1,不可用0，默认1

