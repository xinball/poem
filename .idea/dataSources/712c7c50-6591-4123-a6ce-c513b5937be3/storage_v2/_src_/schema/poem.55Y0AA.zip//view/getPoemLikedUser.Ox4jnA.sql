create view getPoemLikedUser as
select `poem`.`likepoem`.`uid`        AS `uid`,
       `poem`.`poem`.`pid`            AS `pid`,
       `poem`.`poem`.`title`          AS `title`,
       `poem`.`poem`.`did`            AS `did`,
       `poem`.`poem`.`aid`            AS `aid`,
       `poem`.`poem`.`content`        AS `content`,
       `poem`.`poem`.`likepoemnumber` AS `likepoemnumber`,
       `poem`.`poem`.`commentnumber`  AS `commentnumber`,
       `poem`.`poem`.`active`         AS `pactive`,
       `poem`.`dynasty`.`dname`       AS `dname`,
       `poem`.`dynasty`.`active`      AS `dactive`,
       `poem`.`author`.`aname`        AS `aname`,
       `poem`.`author`.`active`       AS `aactive`
from (((`poem`.`likepoem` join `poem`.`poem` on ((`poem`.`likepoem`.`pid` = `poem`.`poem`.`pid`))) join `poem`.`author` on ((`poem`.`poem`.`aid` = `poem`.`author`.`aid`)))
         join `poem`.`dynasty` on ((`poem`.`poem`.`did` = `poem`.`dynasty`.`did`)));

-- comment on column getPoemLikedUser.uid not supported: 用户编号

-- comment on column getPoemLikedUser.pid not supported: 诗词编号

-- comment on column getPoemLikedUser.title not supported: 诗词题目

-- comment on column getPoemLikedUser.did not supported: 朝代编号

-- comment on column getPoemLikedUser.aid not supported: 作者编号

-- comment on column getPoemLikedUser.content not supported: 诗词内容

-- comment on column getPoemLikedUser.likepoemnumber not supported: 喜欢数量

-- comment on column getPoemLikedUser.commentnumber not supported: 评论数量

-- comment on column getPoemLikedUser.pactive not supported: 是否可用1,不可用0，默认1

-- comment on column getPoemLikedUser.dname not supported: 朝代名称

-- comment on column getPoemLikedUser.dactive not supported: 是否可用1,不可用0，默认1

-- comment on column getPoemLikedUser.aname not supported: 作者名称

-- comment on column getPoemLikedUser.aactive not supported: 是否可用1,不可用0
，默认1

