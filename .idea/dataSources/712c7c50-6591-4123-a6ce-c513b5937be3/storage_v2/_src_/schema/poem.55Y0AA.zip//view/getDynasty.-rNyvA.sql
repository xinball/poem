create view getDynasty as
select `poem`.`dynasty`.`did`                                                                                      AS `did`,
       `poem`.`dynasty`.`dname`                                                                                    AS `dname`,
       `poem`.`dynasty`.`active`                                                                                   AS `active`,
       (select count(`poem`.`author`.`aid`)
        from `poem`.`author`
        where (`poem`.`author`.`did` = `poem`.`dynasty`.`did`))                                                    AS `authorcount`,
       (select count(`poem`.`poem`.`pid`)
        from `poem`.`poem`
        where (`poem`.`poem`.`did` = `poem`.`dynasty`.`did`))                                                      AS `poemcount`
from `poem`.`dynasty`;

-- comment on column getDynasty.did not supported: 朝代编号

-- comment on column getDynasty.dname not supported: 朝代名称

-- comment on column getDynasty.active not supported: 是否可用1,不可用0，默认1

