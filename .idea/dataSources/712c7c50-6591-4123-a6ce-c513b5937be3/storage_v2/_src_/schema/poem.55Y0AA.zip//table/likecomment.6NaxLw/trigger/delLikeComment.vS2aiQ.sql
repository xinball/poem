create definer = root@localhost trigger delLikeComment
    after delete
    on likecomment
    for each row
BEGIN
UPDATE poem.`user` SET `user`.`likecommentnumber` = `user`.`likecommentnumber`-1 WHERE `user`.uid=old.uid;
UPDATE poem.`comment` SET `comment`.`likenumber` = `comment`.`likenumber`-1 WHERE `comment`.cid=old.cid;
END;

