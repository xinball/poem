create definer = root@localhost trigger delLikeComment
    after delete
    on likecomment
    for each row
BEGIN
UPDATE poem.`user` SET `user`.`likecommentnumber` = `user`.`likecommentnumber`-1 WHERE `user`.uid=old.uid;
END;

