</head>
<body>
<a class="big" href="/item/index">成功添加<?php echo $count ?>条记录，点击返回</a>
