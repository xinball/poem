
<style>
    input::-webkit-input-placeholder, textarea::-webkit-input-placeholder {
        color: #FFFFFF;
    }

    input:-moz-placeholder, textarea:-moz-placeholder {
        color: #FFFFFF;
    }

    input::-moz-placeholder, textarea::-moz-placeholder {
        color: #FFFFFF;
    }

    input:-ms-input-placeholder, textarea:-ms-input-placeholder {
        color: #FFFFFF;
    }
    .footer{
        background: #22222280 url(/img/bg/footer.png) center center repeat scroll;
        color: white;
    }
</style>
<script>
    $(function () {
        $('body').find('nav').attr('class',"navbar navbar-expand-lg navbar-light bg-light fixed-top navbar-dark bg-dark");
        $('#search').attr('class', 'btn btn-success');
    });
</script>