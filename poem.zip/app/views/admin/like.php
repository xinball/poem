
<style>

</style>
</head>
<body>
<?php
foreach ($users as $user){
    echo $user['uid'];
}
echo $navigation;
?>
