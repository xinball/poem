
<img src="/img/bg/qljst<?php try {
    echo random_int(1, 15);
} catch (Exception $e) {
} ?>.png" class="bgImg" />
