
<img src="/img/bg/qljst<?php try {
    echo date('d')%15+1;
} catch (Exception $e) {
} ?>.webp" class="bgImg" />
