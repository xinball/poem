<?php


namespace app\controllers;

use xbphp\base\Controller;

class NewsController extends Controller
{

}