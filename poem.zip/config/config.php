<?php
// 数据库配置
$config['db']['hostname'] = 'localhost';
$config['db']['username'] = 'poem';
$config['db']['database'] = 'poem';
$config['db']['password'] = 'webpoem';

// 默认控制器和操作名
$config['defaultController'] = 'Index';
$config['defaultAction'] = 'index';

return $config;