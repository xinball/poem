document.onselectstart = function(){return false;}
